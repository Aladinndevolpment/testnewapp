export const dashboardData = [
  { origin: { x: 0, y: 0, h: 5, w: 6 }, component: "chart" },
  { origin: { x: 6, y: 0, h: 5, w: 6 }, component: "calender" },
  { origin: { x: 0, y: 5, h: 5, w: 6 }, component: "email" },
  { origin: { x: 6, y: 6, h: 2, w: 3 }, component: "numbers" },
  { origin: { x: 9, y: 5, h: 2, w: 3 }, component: "numbers" },
  { origin: { x: 6, y: 6, h: 2, w: 3 }, component: "numbers" },
  { origin: { x: 9, y: 7, h: 2, w: 3 }, component: "numbers" },
];
